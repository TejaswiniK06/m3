﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace Listcontrols
{
    public partial class Radiobuttonlst : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
        {
            BindList();
        }

        }


        private void BindList()
        {
            SqlConnection conn = new SqlConnection("Data Source =(localdb)\\MSSQLLocalDB; initial catalog = master; Trusted_Connection = true");
        DataSet ds = new DataSet();
        string cmdstr = "select FLDcountryID,FLDcountryname from [TblCountry]";
        SqlDataAdapter adp = new SqlDataAdapter(cmdstr, conn);
        adp.Fill(ds);
        rblCountry.DataSource = ds;
        rblCountry.DataTextField = "FLDcountryname";
        rblCountry.DataValueField = "FLDcountryID";
        rblCountry.DataBind();
       }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
          //  lblValue.Text = "You selected Country is:<br>"+rblCountry.SelectedItem.ToString(); 
        }

        protected void rblCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblValue.Text = "You selected Country is:<br>" + rblCountry.SelectedItem.ToString();
        }
    }
}