﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Listcontrols
{
    public partial class DDLConcepts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
               
                DropDownList1.Items.Add(new ListItem("Select CustomerID", ""));
                DropDownList1.AppendDataBoundItems = true;
                string strConnString = ConfigurationManager.AppSettings["DBConnection"].ToString();
                //String strQuery = "SELECT FldCustId, FldCustName FROM tblCustomer";
                SqlConnection con = new SqlConnection(strConnString);
                SqlCommand cmd = new SqlCommand("selectcustomerDtls");
                cmd.CommandType = CommandType.StoredProcedure;
                
                cmd.Connection = con;
                try
                {
                    con.Open();
                    DropDownList1.DataSource = cmd.ExecuteReader();
                    DropDownList1.DataTextField ="Cid";
                    DropDownList1.DataValueField = "Cid";
                    DropDownList1.DataBind();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {


        String strConnString = ConfigurationManager.AppSettings["DBConnection"].ToString();
        //String strQuery = "SELECT * FROM TblCustomer WHERE FldCustId = @customerid";
        SqlConnection con = new SqlConnection(strConnString);
        SqlCommand cmd = new SqlCommand("selectcustomer");
        cmd.Parameters.AddWithValue("@customerid", DropDownList1.SelectedItem.Value);
        cmd.CommandType = CommandType.StoredProcedure;
       
        cmd.Connection = con;
        try
        {
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                txtname.Text = sdr["CName"].ToString();
                txtAge.Text = sdr["Cage"].ToString();
                txtAddress.Text = sdr["Address"].ToString();
             
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }


        }
    }
