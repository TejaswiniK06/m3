﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pageconcepts
{
    public partial class WebForm3 : System.Web.UI.Page
    {
      

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCity();
            }
        }
        private void LoadCity()
        {
            DropDownList1.Items.Add("Dhaka");
            DropDownList1.Items.Add("Khulna");
            DropDownList1.Items.Add("Rajshahi");
            DropDownList1.Items.Add("Barisal");




        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("Hello Goodbye");
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Write("Welcome");
        }
    }
}