using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pageconcepts
{
  public partial class Samp_le : System.Web.UI.Page
  {
    



    protected void Page_Load(object sender, EventArgs e)
    {
      //if (!IsPostBack)
      //{
      //  Response.Write("Hi Welcome");
      //}
      if (!Page.IsPostBack)
      {
        DropDownList1.Items.Add("India");
        DropDownList1.Items.Add("Bangladesh");
        DropDownList1.Items.Insert(0, " Select The country");
      }


    }

    protected void Button1_Click(object sender, EventArgs e)
    {
      Response.Write("Hi Good Morning");
    }
    
  }
}
