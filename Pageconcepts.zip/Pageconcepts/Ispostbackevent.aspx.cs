﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PageLifeCycle
{
    public partial class Ispostbackevent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           // IsPostBack== false - Means it works for first time form load.  it does not work  when button is clicked .

//IsPostBack== true - Means it does not work for first time form load. 
            //It works when button is clicked. 



          // if (!IsPostBack)
           // {
                LoadCity();
           // }
            //LoadCity();
        }
        private void LoadCity()
        {
            DropDownList1.Items.Add("Dhaka");
            DropDownList1.Items.Add("Khulna");
            DropDownList1.Items.Add("Rajshahi");
            DropDownList1.Items.Add("Barisal");




        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}