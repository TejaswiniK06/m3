﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PageLifeCycle
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
      //going to store the previous page information to the page variable
            Page previousPage = Page.PreviousPage;
            if (previousPage != null && previousPage.IsCrossPagePostBack)
            {

                Label1.Text ="FName:"+ ((TextBox)previousPage.FindControl("txtFname")).Text;
                Label2.Text ="LName:"+ ((TextBox)previousPage.FindControl("txtLname")).Text;
            }
            else
            {
                lblStatus.Text = "you landed on this page using a techinique other than cross page postback";
            }
        }
    }
}