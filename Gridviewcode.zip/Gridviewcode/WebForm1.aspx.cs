using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Gridviewcode
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindData();
            }
        }
        private void BindData()
        {
            string strconnection = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConnection Con = new SqlConnection(strconnection);
            SqlCommand Scmd = new SqlCommand("select *from Customertbl", Con);
            SqlDataAdapter Da = new SqlDataAdapter(Scmd);
            DataSet Ds = new DataSet();
            Da.Fill(Ds, "kamal");
            GridView2.DataSource = Ds;
            GridView2.DataBind();


        }

        protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
        {

            GridView2.EditIndex = e.NewEditIndex;

            BindData();

        }

        protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {


            string strconnection = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConnection Con = new SqlConnection(strconnection);
            Con.Open();
            Label lblupdateid = (Label)GridView2.Rows[e.RowIndex].FindControl("lblId");
           // TextBox txtid = (TextBox)GridView2.Rows[e.RowIndex].Cells[0].Controls[0];
            TextBox txtname = (TextBox)GridView2.Rows[e.RowIndex].Cells[1].Controls[0];
            TextBox txtaddress = (TextBox)GridView2.Rows[e.RowIndex].Cells[2].Controls[0];
            TextBox txtcity = (TextBox)GridView2.Rows[e.RowIndex].Cells[3].Controls[0];
            TextBox txtcountry = (TextBox)GridView2.Rows[e.RowIndex].Cells[4].Controls[0];


            SqlCommand Scmd = new SqlCommand("update Customertbl set fldCustName='" + txtname.Text + "',fldCustaddress='" + txtaddress.Text + "',fldCustCity='" + txtcity.Text + "',fldCustCountry='" + txtcountry.Text + "' where fldCustId=" + lblupdateid.Text + "", Con);
            Scmd.ExecuteNonQuery();
            GridView2.EditIndex = -1;
            Response.Write("Record updated");
            Con.Close();
            BindData();



        }

        protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string strconnection = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConnection Con = new SqlConnection(strconnection);
      Label lbldeleteid = (Label)GridView2.Rows[e.RowIndex].FindControl("lblId");
     // GridViewRow row = (GridViewRow)GridView2.Rows[e.RowIndex];
           // TextBox txtid = (TextBox)GridView2.Rows[e.RowIndex].Cells[0].Controls[0];
         //   Label lbldeleteid = (Label)row.FindControl("lblId");
            Con.Open();
            SqlCommand cmd = new SqlCommand("delete FROM Customertbl where fldCustId='" + lbldeleteid.Text + "'", Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            BindData();


        }

        protected void GridView2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView2.EditIndex = -1;
            BindData();

        }

        protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView2.PageIndex = e.NewPageIndex;
            BindData();
        }
    }
}
