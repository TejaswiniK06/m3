﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Gridviewcode
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }



        private void BindData()
        {
            string strconnection = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConnection Con = new SqlConnection(strconnection);
            SqlCommand Scmd = new SqlCommand("select *from Customertbl", Con);
            SqlDataAdapter Da = new SqlDataAdapter(Scmd);
            DataSet Ds = new DataSet();
            Da.Fill(Ds, "kamal");
            GridView1.DataSource = Ds;
            GridView1.DataBind();


        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            BindData();

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            
            string strconnection = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConnection Con = new SqlConnection(strconnection);
            Con.Open();
            Label lblupdateid = (Label)GridView1.Rows[e.RowIndex].FindControl("lblId");
            // TextBox txtid = (TextBox)GridView2.Rows[e.RowIndex].Cells[0].Controls[0];
            TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0];
            TextBox txtaddress = (TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0];
            TextBox txtcity = (TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0];
            TextBox txtcountry = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0];


            SqlCommand Scmd = new SqlCommand("update Customertbl set fldCustName='" + txtname.Text + "',fldCustaddress='" + txtaddress.Text + "',fldCustCity='" + txtcity.Text + "',fldCustCountry='" + txtcountry.Text + "' where fldCustId=" + lblupdateid.Text + "", Con);
            Scmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;
            Response.Write("Record updated");
            Con.Close();
            BindData();







        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindData();
        }
    }
}