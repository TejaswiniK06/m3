﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Gridviewcode
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {

            //string strcon = ConfigurationManager.ConnectionStrings[]
            //SqlConnection con = new SqlConnection(strcon);
            //SqlCommand com = new SqlCommand("CUser", con);
            //com.CommandType = System.Data.CommandType.StoredProcedure;
            //SqlParameter p1 = new SqlParameter("username", txtuname.Text);
            //SqlParameter p2 = new SqlParameter("password", txtpwd.Text);
            //com.Parameters.Add(p1);
            //com.Parameters.Add(p2);
            //con.Open();
            //SqlDataReader rd = com.ExecuteReader();
            //if (rd.HasRows)
            //{
            //    rd.Read();
            //    Label3.Text = "Login successful.";
            //    Label3.Visible = true;
            //}
            //else
            //{
            //    Label3.Text = "Invalid username or password.";
            //    Label3.Visible = true;
            //}



        }

      
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["DbConnection"].ToString();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand com = new SqlCommand("Emplogin", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@UserName", txtUserId.Text.ToString());  
            com.Parameters.AddWithValue("@Password", txtpwd.Text.ToString());  

            int usercount = (Int32)com.ExecuteScalar();

            if (usercount == 1)  
            {
                Response.Redirect("Welcome.aspx");  
            }
            else
            {
                con.Close();
                Label1.Text = "Invalid User Name or word";  //for invalid login
            }



        }
    }
}