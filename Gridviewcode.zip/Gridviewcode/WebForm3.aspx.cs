﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Gridviewcode
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }
        private void BindData()
        {
            string strconnection = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConnection Con = new SqlConnection(strconnection);
            SqlCommand Scmd = new SqlCommand("select *from Customertbl", Con);
            SqlDataAdapter Da = new SqlDataAdapter(Scmd);
            DataSet Ds = new DataSet();
            Da.Fill(Ds, "kamal");
            GridView1.DataSource = Ds;
            GridView1.DataBind();


        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            BindData();


        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }
    }
}