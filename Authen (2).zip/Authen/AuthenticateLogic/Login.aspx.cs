using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace AuthenticateLogic
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
      
        }



        protected void Login_Click(object sender, EventArgs e)
        {
            if (AuthenticateUser(UserName.Text, UserPass.Text))
            {
                FormsAuthentication.RedirectFromLoginPage(UserName.Text, chkboxPersist.Checked);
            }
            else
            {
                Msg.Text = "Invalid UserName/Password";
            }
        }
        private bool AuthenticateUser(string Username, string password)
        {

      string Connection = "Data Source=DESKTOP-Q4AUS42;uid=sa;pwd=sa123;initial catalog=Authenticate";
   
            using (SqlConnection Con = new SqlConnection(Connection))
            {

                SqlCommand cmd = new SqlCommand("spAuthenticateUser", Con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter paramUsername = new SqlParameter("@UserName", Username);
                SqlParameter paramPassword = new SqlParameter("@Password", password);
                cmd.Parameters.Add(paramUsername);
                cmd.Parameters.Add(paramPassword);
                Con.Open();
                int ReturnCode = (int)cmd.ExecuteScalar();
                return ReturnCode == 1;

            }

        }






  

    protected void BtnRegister_Click(object sender, EventArgs e)
    {
      Response.Redirect("Register.aspx");
    }
  }
}

