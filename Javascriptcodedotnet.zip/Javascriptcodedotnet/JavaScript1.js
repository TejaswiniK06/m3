﻿function IsEven() {
    var Number = document.getElementById('txtNum').value;
    if (Number % 2 == 0) {
        alert(Number + "is Even Number");
    }
    else {
        alert(Number + "is  Not Even Number");
    }
}