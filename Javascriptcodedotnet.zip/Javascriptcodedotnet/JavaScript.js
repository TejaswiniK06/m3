function validate() {

  //var email = document.myForm.Name.value;

  if (document.myForm.Name.value == "") {
    alert("Please provide your name!");
    document.myForm.Name.focus();
    return false;
  }
  if (document.myForm.Password.value == "") {
    alert("Please provide your Password!");
    document.myForm.Password.focus();
    return false;
  }

  if (document.myForm.EMail.value == "") {
    alert("Please provide your Email!");
    document.myForm.EMail.focus();
    return false;
  }

  if (document.myForm.EMail.value.indexOf("@", 0) <= 0) {
    window.alert("Please enter a valid e-mail address.");
    EMail.focus();
    return false;
  }

  if (document.myForm.EMail.value.indexOf(".", 0) <= 0) {
    window.alert("Please enter a valid e-mail address.");
    EMail.focus();
    return false;
  }

  if (document.myForm.Zip.value == "" ||
    isNaN(document.myForm.Zip.value) ||
    document.myForm.Zip.value.length != 6) {
    alert("Please provide a zip in the format ######.");
    document.myForm.Zip.focus();
    return false;
  }

  var a = document.myForm.Country.value;

  if (document.myForm.Country.value =="-1") {
    alert("Please provide your country!");
    return false;
  }
  return (true);
}
