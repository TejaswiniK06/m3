﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace Javascriptcodedotnet
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-Q4AUS42;uid=sa;pwd=sa123;initial catalog=Northwind");

            con.Open();

            SqlCommand cmd = new SqlCommand("SpInsertData");
            cmd.Connection = con;

            SqlParameter Pmusername = new SqlParameter();
            Pmusername.ParameterName = "@username";// Defining Name
            Pmusername.SqlDbType = SqlDbType.VarChar; // Defining DataType
            Pmusername.Direction = ParameterDirection.Input; // Setting the direction 

            //Creating instance of SqlParameter 
            SqlParameter Pmpassword = new SqlParameter();
            Pmpassword.ParameterName = "@password";// Defining Name
            Pmpassword.SqlDbType = SqlDbType.VarChar; // Defining DataType
            Pmpassword.Direction = ParameterDirection.Input;// Setting the direction 

            //Creating instance of SqlParameter 
            SqlParameter PmEmail = new SqlParameter();
            PmEmail.ParameterName = "@Email"; // Defining Name
            PmEmail.SqlDbType = SqlDbType.VarChar; // Defining DataType
            PmEmail.Direction = ParameterDirection.Input;// Setting the direction 

            SqlParameter PmGender = new SqlParameter();
            PmGender.ParameterName = "@Gender"; // Defining Name
            PmGender.SqlDbType = SqlDbType.VarChar; // Defining DataType
            PmGender.Direction = ParameterDirection.Input;// Setting the direction 

            // Adding Parameter instances to sqlcommand
            Pmusername.Value = txtUserId.Text;
            Pmpassword.Value = txtpwd.Text;
            PmEmail.Value= txtmail.Text;
            PmGender.Value = ddlType.SelectedItem.Text;

            cmd.Parameters.Add(Pmusername);
            cmd.Parameters.Add(Pmpassword);
            cmd.Parameters.Add(PmEmail);
            cmd.Parameters.Add(PmGender);
            cmd.CommandText = "insert into UserData values(@username,@password,@Email,@Gender)";

            // Setting values of Parameter 
            try{
            cmd.ExecuteNonQuery();
           // con.Close();
            Response.Write("Record Inserted");
            }
            catch (Exception)
            {
                Response.Write("Not Saved");
            }
            finally
            {
                con.Close();
            }



            Label1.Visible = false;
           
        }

        protected void txtUserId_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-Q4AUS42;uid=sa;pwd=sa123;initial catalog=Northwind");

        con.Open();

        SqlCommand cmd = new SqlCommand("select*from UserData where UserName='" + txtUserId.Text + "'", con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())

        {
            Label1.Text = "User Name is Already Exist";

            this.Label1.ForeColor = Color.Red;
        }

        else
        {
            Label1.Text = "UserName is Available";

            this.Label1.ForeColor = Color.Green;

        }
        con.Close();
        }

       

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            
        }
    }
}