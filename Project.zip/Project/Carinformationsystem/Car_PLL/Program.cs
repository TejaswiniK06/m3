﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CAREntityLayer;
using CARException;
using Car_BLL;
using Car_DAL;
namespace Car_PLL
{
    class Program
    {
        static void Main(string[] args)
        {
            CarBL.setlist();

            int choice;
            do
            {
                Print();
                Console.WriteLine("Enter your choice");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddcarPL();

                        break;
                    case 2:
                        ModifycarPL();

                        break;
                    case 3:
                        SearchcarPL();

                        break;
                    case 4:
                        RemovePL();

                        break;
                    case 5:
                        ShowallPL();

                        break;
                   
                    case 6:
                        return;
                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }

            } while (choice > 0 && choice < 8);

            Console.ReadKey();


        }

        public static void AddcarPL()
        {
            CarEntities car = new CarEntities();
            try
            {
                Console.Clear();
                Console.WriteLine("********************************************************************************");
                Console.WriteLine("                                 Add CAR Details                           ");
                Console.WriteLine("********************************************************************************");
                Console.WriteLine("Enter Manufacturer Name");
                car.ManufacturerName = Console.ReadLine();
                Console.WriteLine("Enter Car Model");
                car.Model = Console.ReadLine();
                Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                car.Type = Console.ReadLine();
                Console.WriteLine("Enter Engine");
                car.Engine = Console.ReadLine();
                Console.WriteLine("Enter BHP");
                car.BHP = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                car.Transmission = Console.ReadLine();
                Console.WriteLine("Enter Mileage");
                car.Mileage = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter no. of seats");
                car.Seats = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Airbags details");
                car.Airbags = Console.ReadLine();
                Console.WriteLine("Enter BootSpace");
                car.BootSpace = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Price");
                car.price = double.Parse(Console.ReadLine());


                bool added = CarBL.AddBLL(car);
                if (added)
                    Console.WriteLine("Car Details are added successfully");
                else
                    Console.WriteLine("Details are not added ");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void ModifycarPL()
        {

            try
            {
                string model;
                Console.WriteLine("********************************************************************************");
                Console.WriteLine("                                 Modify Car Details                           ");
                Console.WriteLine("********************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine("Enter Manufacturer Name");
                    car.ManufacturerName = Console.ReadLine();

                    Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                    car.Type = Console.ReadLine();
                    Console.WriteLine("Enter Engine");
                    car.Engine = Console.ReadLine();
                    Console.WriteLine("Enter BHP");
                    car.BHP = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                    car.Transmission = Console.ReadLine();
                    Console.WriteLine("Enter Mileage");
                    car.Mileage = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter no. of seats");
                    car.Seats = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Airbags details");
                    car.Airbags = Console.ReadLine();
                    Console.WriteLine("Enter BootSpace");
                    car.BootSpace = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Price");
                    car.price = double.Parse(Console.ReadLine());
                    bool modified = CarBL.ModifyBLL(car);
                    if (modified)
                        Console.WriteLine("Car Details are updated");
                    else
                        Console.WriteLine("Car Details are not updated");
                }
                else
                    Console.WriteLine("No car details available to modify");
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        public static void SearchcarPL()
        {
            string model;

            try
            {

                Console.WriteLine("********************************************************************************");
                Console.WriteLine("                                 Search car                           ");
                Console.WriteLine("********************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine("Car is found");
                    Console.WriteLine("ManufacturerName\tModel\t\tType\t\tPrice");
                    Console.WriteLine("*****************************************************************************");
                    Console.WriteLine(car.ManufacturerName + "\t" + car.Model + "\t" + car.Type + "\t" + car.price);
                    Console.WriteLine("*****************************************************************************");

                }
                else
                    Console.WriteLine("No Car details found");

            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void RemovePL()
        {
            try
            {
                string model;

                Console.WriteLine("********************************************************************************");
                Console.WriteLine("                                 Remove Car Details                           ");
                Console.WriteLine("********************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();

                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine(" Are you sure you want to delete car\t" + model + "\tenter 1 for Yes or 2 for No");
                    int x = int.Parse(Console.ReadLine());
                    switch (x)
                    {
                        case 1:
                            bool removed = CarBL.RemoveBLL(model);
                            if (removed)
                                Console.WriteLine("Car Details are removed successfully");
                            else
                                Console.WriteLine("Details are not removed ");
                            break;
                        case 2:
                            break;
                        default:
                            Console.WriteLine("Invalid choice");
                            break;

                    }
                }
                else
                    Console.WriteLine("model not found to delete");
            }
           
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


        }

        public static void ShowallPL()
        {

            try
            {
                List<CarEntities> carlist = Car_BLL.CarBL.ShowBLL();
                if (carlist != null && carlist.Count > 0)
                {
                    Console.Clear();
                    Console.WriteLine("*******************************************************************************");
                    Console.WriteLine("                                List of  all Cars                           ");
                    Console.WriteLine("********************************************************************************");
                    carlist = CarBL.ShowBLL();

                    Console.WriteLine("*********************************************************************************");
                    Console.WriteLine("ManufacturerName\tModel\t\tType\t\tPrice");
                    Console.WriteLine("*********************************************************************************");
                    foreach (CarEntities car in carlist)
                    {


                        Console.WriteLine(car.ManufacturerName + "\t\t" + car.Model + "\t\t" + car.Type + "\t\t" + car.price);
                    }

                }
                else
                    Console.WriteLine("No car details available");

            }


            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void Print()
        {
            Console.WriteLine("********************************************************************************");
            Console.WriteLine("                                 Car Details                           ");
            Console.WriteLine("********************************************************************************");
            Console.WriteLine("1. Add Car ");
            Console.WriteLine("2. Modify car");
            Console.WriteLine("3. Search Car");
            Console.WriteLine("4. Remove car");
            Console.WriteLine("5. Show list");
            Console.WriteLine("6. Exit");


        }


        private static void SetSerialization()
        {
            try
            {
                Car_BLL.CarBL.SetSerialization();
            }
            catch (CARException.Myexception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
