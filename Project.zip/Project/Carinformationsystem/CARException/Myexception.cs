﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CARException
{
    public class Myexception : ApplicationException
    {
        public Myexception() : base() { }

        public Myexception(string message) : base(message) { }

        public Myexception(string message, Exception innerException) : base(message, innerException) { }
    }
   
}
