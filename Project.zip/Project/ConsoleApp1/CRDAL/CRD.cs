﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRENTITY;
using CRException;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CRDAL
{
    public class CRD
    {
        static List<CREntities> carList = new List<CREntities>();
        public static string fileName = "CarDetails.txt";
        public bool AddCarDAL(CREntities car)
        {
            bool added = false;
            try
            {
                carList.Add(car);
                Serialization();
                added = true;
            }
            catch (SystemException cex)
            {
                throw new CRExceptions(cex.Message);
            }
            return added;
        }

        public bool UpdateCarDAL(CREntities cr)
        {
            Deserialization();
            bool updated = false;
            try
            {
                for (int i = 0; i < carList.Count; i++)
                {
                    if (cr.CId == carList[i].CId)
                    {
                        carList[i].CTitle = cr.CTitle;
                        carList[i].CDesc = cr.CDesc;
                        carList[i].CModel = cr.CModel;
                        carList[i].CBrand = cr.CBrand;
                        carList[i].RCStatus = cr.RCStatus;
                        carList[i].PurchaseYear = cr.PurchaseYear;
                        carList[i].sellerId = cr.sellerId;
                        carList[i].ExpectedPrice = cr.ExpectedPrice;
                        carList[i].AddedDate = cr.AddedDate;
                        updated = true;
                    }
                }
                Serialization();
            }
            catch (SystemException cex)
            {
                throw new CRExceptions(cex.Message);
            }
            return updated;
        }

        public CREntities SearchCarDAL(string id)
        {
            Deserialization();
            CREntities car = new CREntities();
            try
            {
                car = carList.Find(cr => cr.CId == id);
            }
            catch (SystemException cex)
            {
                throw new CRExceptions(cex.Message);
            }
            return car;

        }

        public List<CREntities> DisplayAllDAL()
        {
            try
            {
                Deserialization();
                return carList;
            }
            catch (SystemException cex)
            {
                throw new CRExceptions(cex.Message);
            }
        }


        public void Serialization()
        {
            try
            {
                FileStream fileStream = new FileStream(fileName, FileMode.Append);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, carList);
                fileStream.Close();
                //carList.Clear();
            }
            catch (SystemException cex)
            {
                throw new CRExceptions(cex.Message);
            }
        }


        public void Deserialization()
        {
            try
            {
                FileStream fileStream = new FileStream(fileName, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                List<CREntities> carList = binaryFormatter.Deserialize(fileStream) as List<CREntities>;
                carList.Clear();
                foreach (CREntities car in carList)
                    carList.Add(car);
                fileStream.Close();
            }
            catch (SystemException cex)
            {
                throw new CRExceptions(cex.Message);
            }
        }
    }
}
