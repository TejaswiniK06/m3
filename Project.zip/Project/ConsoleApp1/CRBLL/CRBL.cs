﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRENTITY;
using CRException;
using CRDAL;
using System.Text.RegularExpressions;

namespace CRBLL
{
    public class CRBL
    {
        public static bool Validate(CREntities cr)
        {
            bool validate = true;
            try
            {
                if (!Regex.IsMatch(cr.CDesc, @"[\w\.\s\,]{150,}"))
                {
                    validate = false;
                    throw new CRExceptions("description should be minimum 150 characters long");
                }
                if (cr.PurchaseYear > DateTime.Now.Year)
                {
                    validate = false;
                    throw new CRExceptions("Date should be before today");
                }
                if (cr.ExpectedPrice <=0)
                {
                    validate = false;
                    throw new CRExceptions("Price should be greater than zero");
                }
                if (cr.AddedDate.Date != DateTime.Now.Date)
                {
                    validate = false;
                    throw new CRExceptions("Added date will be current date");
                }
            }
            catch (CRExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validate;
        }

        public static bool AddCarBLL(CREntities car)
        {
            bool added = false;
            try
            {
                if (Validate(car))
                {
                    CRD cd = new CRD();
                    added = cd.AddCarDAL(car);
                }
            }
            catch (CRExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }

        public static bool UpdateCarBLL(CREntities cr)
        {
            bool updated = false;
            try
            {
                if (Validate(cr))
                {
                    CRD cDD = new CRD();
                    updated = cDD.UpdateCarDAL(cr);
                }
            }
            catch (CRExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return updated;
        }

        public static CREntities SearchCarBLL(string id)
        {
            CREntities car = new CREntities();
            try
            {
                bool flag=false;
                    CRD cDD = new CRD();
                car = cDD.SearchCarDAL(id);
                if(car!=null)
                {
                   flag= cDD.UpdateCarDAL(car);
                }
                Console.WriteLine(flag);
            }
            catch (CRExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return car;
        }

        public static List<CREntities> DisplayAllBLL()
        {
            List<CREntities> carList = new List<CREntities>();
            try
            {
                CRD ed = new CRD();
                carList = ed.DisplayAllDAL();

            }
            catch (CRExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carList;
        }
    }
}
