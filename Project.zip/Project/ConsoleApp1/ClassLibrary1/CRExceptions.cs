﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRException
{
    public class CRExceptions:ApplicationException
    {
        public CRExceptions() : base()
        {

        }
        public CRExceptions(string message) : base(message)
        {

        }
        public CRExceptions(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
