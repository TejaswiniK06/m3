﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRENTITY;
using CRException;
using CRDAL;
using CRBLL;

namespace CRPL 
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice;
                do
                {
                    Print();
                    Console.WriteLine("Enter your choice");
                    choice = Int32.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCarPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 2:
                            UpdateCarPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 3:
                            SearchCarPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 4:
                            DisplayAllPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 5:
                            return;
                    }

                } while (choice != -1);
            }
            catch (CRExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void AddCarPL()
        {
            CREntities car = new CREntities();
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Add Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter the Car Id:");
                car.CId = Console.ReadLine();
                Console.WriteLine("Enter the title of the car:");
                car.CTitle = Console.ReadLine();
                Console.WriteLine("Enter the description of the car:");
                car.CDesc = Console.ReadLine();
                Console.WriteLine("Enter the car model");
                car.CModel = Console.ReadLine();
                Console.WriteLine("Enter the car Brand:");
                car.CBrand = Console.ReadLine();
                Console.WriteLine("Enter the RC Status:");
                car.RCStatus = Console.ReadLine();
                Console.WriteLine("Enter the Purchase year:");
                car.PurchaseYear = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter the seller id:");
                car.sellerId = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Expexted price:");
                car.ExpectedPrice = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Added date:");
                car.AddedDate = DateTime.Parse(Console.ReadLine());
                bool added = CRBL.AddCarBLL(car);
                if (added)
                    Console.WriteLine("car Details are added successfully");
                else
                    Console.WriteLine("Details are not added ");
            }
            catch (CRExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCarPL()
        {
            string id;
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Update Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter the Car Id");
                id = Console.ReadLine();
                CREntities cr = CRBL.SearchCarBLL(id);
                if (cr != null)                                                                                                    
                {
                    Console.Write("Enter the car title:");
                    cr.CTitle = Console.ReadLine();
                    //Console.WriteLine("Enter the carloyee Date of Joining:");
                    Console.WriteLine("Enter the description of the car:");
                    cr.CDesc = Console.ReadLine();
                    Console.WriteLine("Enter the car model");
                    cr.CModel = Console.ReadLine();
                    Console.WriteLine("Enter the car Brand:");
                    cr.CBrand = Console.ReadLine();
                    Console.WriteLine("Enter the RC Status:");
                    cr.RCStatus = Console.ReadLine();
                    Console.WriteLine("Enter the Purchase year:");
                    cr.PurchaseYear = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the seller id:");
                    cr.sellerId = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the Expected price:");
                    cr.ExpectedPrice = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Added date:");
                    cr.AddedDate = DateTime.Parse(Console.ReadLine());
                    //cr.ExpectedPrice = Int32.Parse(Console.ReadLine());
                    bool updated = CRBL.UpdateCarBLL(cr);
                    if (updated)

                        Console.WriteLine("car Details are updated");
                    else
                        Console.WriteLine("car Details are not updated");
                }
                else
                    Console.WriteLine("ID not found");
            }
            catch (CRExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchCarPL()
        {
            string id;
            CREntities cr;
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Search car                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter the car Id");
                id = Console.ReadLine();
                cr = CRBL.SearchCarBLL(id);
                if (cr != null)
                {
                    Console.WriteLine("car is found");
                    Console.WriteLine("*********************************************************************************");
                    Console.WriteLine(cr.CId + "\t" + cr.CTitle + "\t" + cr.CDesc + "\t" + cr.CModel + "\t" + cr.CBrand + "\t" + cr.RCStatus + "\t" + cr.PurchaseYear + "\t" + cr.sellerId + "\t" + cr.ExpectedPrice + "\t" + cr.AddedDate);
                    Console.WriteLine("*********************************************************************************");

                }
                else
                    Console.WriteLine("car not found");

            }
            catch (CRExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DisplayAllPL()
        {
            List<CREntities> cars = new List<CREntities>();
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Display All car details                           ");
                Console.WriteLine("************************************************************************************");
                cars = CRBL.DisplayAllBLL();
                Console.WriteLine("*********************************************************************************");
                Console.WriteLine("car Id\tcar title\tcar description\tcar model\tcar brand\tRC status\tPurchase year\tseller id\texpected price\tadded date");
                Console.WriteLine("*********************************************************************************");
                foreach (CREntities cr in cars)
                    Console.WriteLine(cr.CId + "\t" + cr.CTitle + "\t" + cr.CDesc + "\t" + cr.CModel + "\t" + cr.CBrand + "\t" + cr.RCStatus + "\t" + cr.PurchaseYear + "\t" + cr.sellerId + "\t" + cr.ExpectedPrice + "\t" + cr.AddedDate);
            }
            catch (CRExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void Print()
        {
            Console.WriteLine("************************************************************************************");
            Console.WriteLine("                                 car Details                           ");
            Console.WriteLine("************************************************************************************");
            Console.WriteLine("1. Add New car details");
            Console.WriteLine("2. Update car details");
            Console.WriteLine("3. Search car details");
            Console.WriteLine("4. Display All cars");
            Console.WriteLine("5. Exit");
        }
    }
}
