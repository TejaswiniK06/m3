﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoException;
using CarInfoEntities;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for UpdateWindow.xaml
    /// </summary>
    public partial class UpdateWindow : Window
    {
        public UpdateWindow()
        {
            InitializeComponent();
        }

        private void Update()
        {
            InitializeComponent();
            txtEng.Visibility = Visibility.Hidden;
            txtBHP.Visibility = Visibility.Hidden;
            txtMileage.Visibility = Visibility.Hidden;
            txtSeat.Visibility = Visibility.Hidden;
            txtAirBag.Visibility = Visibility.Hidden;
            txtBootSpace.Visibility = Visibility.Hidden;
            txtPrice.Visibility = Visibility.Hidden;
            txtManfName.Visibility = Visibility.Hidden;
            txtConPerson.Visibility = Visibility.Hidden;
            txtRegOff.Visibility = Visibility.Hidden;
            cmbTypeId.Visibility = Visibility.Hidden;
            cmbTransId.Visibility = Visibility.Hidden;
        }
        private void Refresh()
        {
            cmbModelToUpdate.Text= "";
          txtEng.Text="";
            (txtBHP.Text)="";
          (txtMileage.Text)="";
          (txtSeat.Text)="";
            txtAirBag.Text="";
             txtBootSpace.Text="";
            txtPrice.Text="";
            txtManfName.Text="";
            txtConPerson.Text="";
             txtRegOff.Text="";
            (cmbTypeId.Text)="";
          (cmbTransId.Text)="";
            DisplayWPF();


        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updatecar();
        }

        private void updatecar()
        {
            try
            {
                MainCar mainCar = new MainCar();

                Manufacturer manuf = new Manufacturer();
                mainCar.Model = cmbModelToUpdate.Text;
                mainCar.Engine = txtEng.Text;
                mainCar.BHP = int.Parse(txtBHP.Text);
                mainCar.Mileage = int.Parse(txtMileage.Text);
                mainCar.Seat = int.Parse(txtSeat.Text);
                mainCar.AirBagDetails = txtAirBag.Text;
                mainCar.BootSpace = txtBootSpace.Text;
                mainCar.Price = txtPrice.Text;
                manuf.ManufacturerName = txtManfName.Text;
                manuf.ContactPerson = txtConPerson.Text;
                manuf.RegisteredOffice = txtRegOff.Text;
                mainCar.TypeId = Convert.ToInt32(cmbTypeId.SelectedValue);
                mainCar.TransmissionId = Convert.ToInt32(cmbTransId.SelectedValue);

                CarBLL bLL = new CarBLL();

                if (bLL.UpdateByAdminBLL(mainCar, manuf))
                {
                    MessageBox.Show("Car " + mainCar.Model + "  details Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to update car "+ mainCar.Model + " details");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetTrans()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTransmissionTableBLL();
                cmbTransId.ItemsSource = translist.DefaultView;
                cmbTransId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTransId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTypeTableBLL();
                cmbTypeId.ItemsSource = translist.DefaultView;
                cmbTypeId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTypeId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetTypeId();
            GetTrans();
            DisplayWPF();
           
        }
        private void DisplayWPF()
        {
            try
            {
                CarBLL bLL = new CarBLL();
                DataTable dt = bLL.DisplayAllBLL();
                dg.DataContext = dt;
                if (dt.Rows.Count > 0)
                {


                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        cmbModelToUpdate.Items.Add(dt.Rows[x]["Model"].ToString());


                    }
                }
                else
                {
                    MessageBox.Show("No details are available");
                }

                }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Refresh();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchToUpdate();
        }
        private void SearchToUpdate()
        {
            try
            {
                CarBLL bLL = new CarBLL();
                string model = cmbModelToUpdate.Text;
                DataTable dt = bLL.SearchByModelBLL(model);
                while (dt.Rows.Count > 0)

                {
                    txtEng.Visibility = Visibility.Visible;
                    txtBHP.Visibility = Visibility.Visible;
                    txtMileage.Visibility = Visibility.Visible;
                    txtSeat.Visibility = Visibility.Visible;
                    txtAirBag.Visibility = Visibility.Visible;
                    txtBootSpace.Visibility = Visibility.Visible;
                    txtPrice.Visibility = Visibility.Visible;
                    txtManfName.Visibility = Visibility.Visible;
                    txtConPerson.Visibility = Visibility.Visible;
                    txtRegOff.Visibility = Visibility.Visible;
                    cmbTypeId.Visibility = Visibility.Visible;
                    cmbTransId.Visibility = Visibility.Visible;



                    txtEng.Text = dt.Rows[0]["Engine"].ToString();
                    txtPrice.Text = dt.Rows[0]["Price"].ToString();
                    txtAirBag.Text = dt.Rows[0]["AirBagDetails"].ToString();
                    txtBootSpace.Text = dt.Rows[0]["BootSpace"].ToString();
                    txtBHP.Text = dt.Rows[0]["BHP"].ToString();
                    txtMileage.Text = dt.Rows[0]["Mileage"].ToString();
                    txtManfName.Text = dt.Rows[0]["ManufacturerName"].ToString();
                    txtConPerson.Text = dt.Rows[0]["ContactPerson"].ToString();
                    txtSeat.Text = dt.Rows[0]["Seat"].ToString();
                    txtRegOff.Text = dt.Rows[0]["RegisteredOffice"].ToString();
                    cmbTypeId.SelectedValue = dt.Rows[0]["TypeId"].ToString();
                    cmbTransId.SelectedValue = dt.Rows[0]["TransmissionId"].ToString();



                    break;
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        private void ListBymanufacturer()
        {
            try
            {
                CarBLL bLL = new CarBLL();
                string manufacturer = txtManfName.Text;
                string cartype = cmbTypeId.Text;
                DataTable dt = bLL.SearchByAdminBLL(manufacturer, cartype);
                dg.DataContext = dt;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnListby_Click(object sender, RoutedEventArgs e)
        {
            ListBymanufacturer();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            deletecar();
        }
        private void deletecar()
        {
            try
            {
                MainCar mainCar = new MainCar();
                string Model = cmbModelToUpdate.Text;
                CarBLL bLL = new CarBLL();

                if (bLL.DeleteBLL(Model))
                {
                    MessageBox.Show("Car " + Model + " Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to delete car " + Model);
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
