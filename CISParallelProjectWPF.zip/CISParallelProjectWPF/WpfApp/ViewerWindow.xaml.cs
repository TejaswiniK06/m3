﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoException;
using CarInfoEntities;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for ViewerWindow.xaml
    /// </summary>
    public partial class ViewerWindow : Window
    {
        public ViewerWindow()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            DisplayforViewers();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Searchmodel()
        {
                try
                {
                    // MainCar car = new MainCar();
                    CarBLL bLL = new CarBLL();
                    string model = (cmbModels.Text);

                    DataTable dt = bLL.SearchByModelBLL(model);
                    dg.DataContext = dt;



                }
                catch (CarException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        private void DisplayforViewers()
        {
            CarBLL bLL = new CarBLL();
            DataTable dt = bLL.DisplayAllBLL();
            dg.DataContext = dt;
            if (dt.Rows.Count > 0)
            {

                //while (dt.Rows.Count > 0)

                //{
                //    //  dt.Rows[0]["Engine"].ToString();
                for (int x = 0; x < dt.Rows.Count; x++)
                {
                    cmbModels.Items.Add(dt.Rows[x]["Model"].ToString());
                }


            }
        }
        
    }
}
