﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarInfoDAL;
using CarInfoEntities;
using CarInfoException;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace CarInfoBLL
{
    public class CarBLL
    {

        public static bool ValidateItems(MainCar car,Manufacturer manufacturer)
        {
            bool validate = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (!(Regex.IsMatch(car.Model, @"^[A-Z]{1}[a-z0-9]{2,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Model  first character should be in Caps and Alphabet");

                }
                
                if (!(Regex.IsMatch(car.Engine, @"^\d\.\dL$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Engine name should have 4 characters with 1st and 3rd character number ,2nd '.' and last 'L'");

                }
                if (!(Regex.IsMatch(car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "BHP should be a number");
                }
                
                if (!(Regex.IsMatch(car.Mileage.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Mileage should be a number");
                }
                if (!(Regex.IsMatch(car.Seat.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "seats should be a number");
                }
                if (!(Regex.IsMatch(manufacturer.ContactPerson, @"^[A-Za-z]{1,50}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "ContactPerson details should contain Characters");
                }
                if (!(Regex.IsMatch(manufacturer.ManufacturerName, @"^[A-Za-z]{1,50}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Manufacture Name details should contain Characters");
                }

                if (!(Regex.IsMatch(manufacturer.RegisteredOffice, @"^[A-Za-z]{1,50}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Manufacture Name details should contain Characters");
                }
                if (!(Regex.IsMatch(car.AirBagDetails, @"^[A-Za-z]{1,50}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Airbags details should be a string");
                }
                if (!(Regex.IsMatch(car.BootSpace.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(car.Price.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Price should be a number");
                }

                if (manufacturer.ContactPerson == String.Empty || manufacturer.RegisteredOffice == String.Empty || manufacturer.ManufacturerName == String.Empty || car.Mileage.ToString() == String.Empty || car.Model == String.Empty || car.Seat.ToString() == String.Empty || car.Price.ToString() == String.Empty || car.BootSpace.ToString() == String.Empty || car.AirBagDetails == String.Empty)
                {
                    validate = false;
                    sb.AppendLine("All Fields are  mandatory");
                }
                if (validate == false)

                    throw new CarException(sb.ToString());
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }

        public bool RegistrationSearchBL(string user, string password)
        {
            bool userSearched = false;
            try
            {
                CarDAL dAL = new CarDAL();
                userSearched = dAL.RegistrationSearchDAL(user, password);
            }
            catch (CarException cex)
            {
                throw cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userSearched;
        }

        public bool AddByAdminBLl(MainCar maincar,Manufacturer manufacturer)
        {
            bool isAdded = false;
            try
            {
                if (ValidateItems(maincar, manufacturer))
                {
                    CarDAL carDal = new CarDAL();
                    isAdded = carDal.AddByAdminDal(maincar, manufacturer);
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdded;
        }



        public bool DeleteBLL(string model)
        {
            bool isDeleted = false;
            try
            {
                CarDAL carDal = new CarDAL();
                isDeleted = carDal.DeleteDal(model);

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isDeleted;
        }


        public bool UpdateByAdminBLL(MainCar mainCar, Manufacturer manufacturer)
        {
            bool isUpdated = false;
            try
            {

                if (ValidateItems(mainCar, manufacturer))
                {
                    CarDAL carDal = new CarDAL();
                    isUpdated = carDal.UpdateByAdminDal(mainCar, manufacturer);
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isUpdated;
        }

            public DataTable GetCarTypeTableBLL()
           {
            DataTable dt ;

            try
            {

                CarDAL carDal = new CarDAL();
                dt = carDal.GetCarTypeTableDal();


            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;

            }
        public DataTable DisplayAllBLL()
        {
            DataTable dt;

            try
            {

                CarDAL carDal = new CarDAL();
                dt = carDal.DisplayAll();


            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;

        }


        public DataTable GetCarTransmissionTableBLL()
        {
            DataTable dt ;

            try
            {

                CarDAL carDal = new CarDAL();
                dt = carDal.GetCarTransmissionTableDal();


            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;
        }




        public DataTable SearchByAdminBLL(string mnfname, string cartype)
        {
            DataTable dt = null;

            try
            {

                CarDAL carDal = new CarDAL();
                dt = carDal.SearchByAdminDal(mnfname,cartype);


            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;
        }


        public DataTable SearchByModelBLL(string model)
        {
            DataTable dt = null;

            try
            {

                CarDAL carDal = new CarDAL();
                dt = carDal.SearchByModelDal(model);


            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;
        }


    }


    
}
