﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInfoEntities
{
    public class MainCar
    {
       public int Id { get; set; }
        public string Model { get; set; }
       public int ManufacturerId { get; set; }
       public int  TypeId { get; set; }
      public string   Engine { get; set; }
       public int  BHP { get; set; }
       public int  TransmissionId { get; set; }
       public int Mileage { get; set; }
      public int  Seat { get; set; }
       public string AirBagDetails { get; set; }
       public string  BootSpace { get; set; }
      public string  Price { get; set; }
    }
}
