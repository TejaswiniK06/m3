﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Errorcontrol
{
    public partial class ListBox : Form
    {
        public ListBox()
        {
            InitializeComponent();
        }

        private void ListBox_Load(object sender, EventArgs e)
        {
            List<string> nList = new List<string>();
            nList.Add("January");
            nList.Add("February");
            nList.Add("March");
            nList.Add("April");
            listBox1.DataSource = nList;
            
            listBox1.SelectionMode = SelectionMode.MultiExtended;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Object obj in listBox1.SelectedItems)
            {
                MessageBox.Show(obj.ToString());
            }

        }
    }
}
