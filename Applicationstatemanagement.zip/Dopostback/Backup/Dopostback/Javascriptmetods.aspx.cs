﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Dopostback
{
    public partial class Javascriptmetods : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //type parameter is used  to spcify the type StartupScript that we want to  register  
            //ClientScript.RegisterStartupScript(TextBox1.GetType(), "clientScript", "<script type=\"text/javascript\">document.getElementById('TextBox1').value=new Date()</script>");
            //ClientScript.RegisterClientScriptBlock(TextBox1.GetType(), "clientScript", "document.getElementById('TextBox1').value=new Date();", true);
            //ClientScript.RegisterStartupScript(TextBox1.GetType(), "clientScript", "document.getElementById('TextBox1').value=new Date();", true);
            //ClientScript.RegisterStartupScript(Label1.GetType(), "clientScript", "document.getElementById('Label1').innerHTML=new Date();", true);

        }

    }
}