﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Applicationstatemanagement
{
    public partial class WebUserControl1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblservertime.Text = DateTime.Now.ToString();
            SqlConnection con = new SqlConnection("Data Source=(local);uid=sa;pwd=password-1;initial catalog=kamal");
            SqlCommand cmd = new SqlCommand("spGetproducts");
            cmd.Connection = con;

            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            con.Close();
            // Cache["data"] = ds;     // Storing dataset in cache "data"
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
}