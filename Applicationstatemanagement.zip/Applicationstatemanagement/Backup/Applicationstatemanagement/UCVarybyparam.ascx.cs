﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Applicationstatemanagement
{
    public partial class UCVarybyparam1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
       

                GetByProductByName(Request.QueryString["ProductName"]);
           
                 lblservertime.Text = DateTime.Now.ToString();
        }

        private void GetByProductByName(string ProductName)
        {
            SqlConnection Con = new SqlConnection("Data Source=(local);uid=sa;pwd=password-1;initial catalog=kamal");
            Con.Open();
            SqlDataAdapter Da = new SqlDataAdapter("spGetproductByName", Con);
            Da.SelectCommand.CommandType = CommandType.StoredProcedure;


            SqlParameter paramproductname = new SqlParameter();
            paramproductname.ParameterName = "@ProductName";
            paramproductname.Value = ProductName;
            Da.SelectCommand.Parameters.Add(paramproductname);
            DataSet Ds = new DataSet();
            Da.Fill(Ds);
            GridView1.DataSource = Ds;
            GridView1.DataBind();




        }



        


    }
}