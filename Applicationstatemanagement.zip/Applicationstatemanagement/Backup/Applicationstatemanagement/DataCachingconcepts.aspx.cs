﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
namespace Applicationstatemanagement
{
    public partial class DataCachingconcepts : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void btnDataCache_Click(object sender, EventArgs e)
        {
            StringBuilder sbmessage = new StringBuilder();
            DateTime dtStarttime=DateTime.Now;
            if (Cache["ProductsData"] != null)
            {
                DataSet  Ds = (DataSet)Cache["ProductsData"];
                GvProducts.DataSource = Ds;
                GvProducts.DataBind();
                sbmessage.Append(Ds.Tables[0].Rows.Count.ToString() + "Rows are Retrieved  from cache");
            }
            else{

                DataSet Ds = (DataSet)GetProductsData();
                Cache["ProductsData"]=Ds;
                GvProducts.DataSource = Ds;
                GvProducts.DataBind();
                sbmessage.Append(Ds.Tables[0].Rows.Count.ToString() + "Rows are Retrieved  from DataBase");
            }
           


            DateTime dtEndtime=DateTime.Now;
            int Totaltime=(dtEndtime-dtStarttime).Seconds;
            sbmessage.Append(Totaltime.ToString()+"Total seconds load time");

            Label1.Text=sbmessage.ToString();

            }


          private DataSet  GetProductsData()
          {
                 SqlConnection con = new SqlConnection("Data Source=(local);uid=sa;pwd=password-1;initial catalog=kamal");
                 SqlCommand cmd = new SqlCommand("spGetproducts");
                cmd.Connection = con;

                con.Open();
                cmd.CommandType =CommandType.StoredProcedure;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet dsProducts = new DataSet();
                adp.Fill(dsProducts);
                return dsProducts;

          }

        }
    }
