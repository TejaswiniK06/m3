﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Applicationstatemanagement
{
    public partial class Applicationprgs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Application["Count"] = Convert.ToInt32(Application["Count"]) + 1; //Set Value to The Application Object
            Label1.Text = Application["Count"].ToString(); 

        }
         

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }
    }
}