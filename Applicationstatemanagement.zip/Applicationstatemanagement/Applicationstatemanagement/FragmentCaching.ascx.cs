using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Applicationstatemanagement
{
    public partial class FragmentCaching : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{

            //    GetByProductByName(DropDownList1.SelectedValue);
            //}
            //lblservertime.Text = DateTime.Now.ToString();
        }
        private void GetByProductByName(string ProductName)
        {
            SqlConnection Con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Trusted_Connection=true;initial catalog=master;"); Con.Open();

           SqlCommand scmd = new SqlCommand();
          scmd.CommandText = "spGetproductByName";
          scmd.Connection = Con;
          scmd.CommandType = CommandType.StoredProcedure;
      
            //SqlDataAdapter Da = new SqlDataAdapter("spGetproductByName", Con);

            //Da.SelectCommand.CommandType = CommandType.StoredProcedure;


            SqlParameter paramproductname = new SqlParameter();
            paramproductname.ParameterName = "@ProductName";
            paramproductname.Value = ProductName;
            scmd.Parameters.Add(paramproductname);
      SqlDataAdapter Da = new SqlDataAdapter(scmd);

            //Da.SelectCommand.Parameters.Add(paramproductname);
      DataSet Ds = new DataSet();
            Da.Fill(Ds);
            GridView1.DataSource = Ds;
            GridView1.DataBind();




        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetByProductByName(DropDownList1.SelectedValue);

        }
    }
}
