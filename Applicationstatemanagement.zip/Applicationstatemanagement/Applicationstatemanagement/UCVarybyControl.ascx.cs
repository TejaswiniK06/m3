using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace Applicationstatemanagement
{
    public partial class UCVarybyparam : System.Web.UI.UserControl
    {
       // [PartialCaching (60, VaryByControls="DropDownList1")]
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{

            //    GetByProductByName(DropDownList1.SelectedValue);
            //}
            //lblservertime.Text = DateTime.Now.ToString();
        }

        private void GetByProductByName(string ProductName)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Trusted_Connection=true;initial catalog=master;");
            con.Open();
            SqlDataAdapter Da = new SqlDataAdapter("spGetproductByName",con);
            Da.SelectCommand.CommandType = CommandType.StoredProcedure;


            SqlParameter paramproductname = new SqlParameter();
            paramproductname.ParameterName = "@PName";
            paramproductname.Value = ProductName;
            Da.SelectCommand.Parameters.Add(paramproductname);
            DataSet Ds = new DataSet();
            Da.Fill(Ds);
            GridView1.DataSource = Ds;
            GridView1.DataBind();




        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           GetByProductByName(DropDownList1.SelectedValue);

        }
    }
}
