using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Data;
namespace Applicationstatemanagement
{
    public partial class DataCaching1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            StringBuilder sbmessage = new StringBuilder();
            DateTime dtStarttime = DateTime.Now;
            if (Cache["PData"] != null)
            {
                DataSet Ds = (DataSet)Cache["PData"];
                GridView1.DataSource = Ds;
                GridView1.DataBind();
                sbmessage.Append(Ds.Tables[0].Rows.Count.ToString() + "Rows are Retrieved  from cache");
            }
            else
            {

                DataSet Ds = (DataSet)GetEmployeesData();
                Cache["PData"] = Ds;
                GridView1.DataSource = Ds;
                GridView1.DataBind();
                sbmessage.Append(Ds.Tables[0].Rows.Count.ToString() + "Rows are Retrieved  from DataBase");
            }



            DateTime dtEndtime = DateTime.Now;
            int Totaltime = (dtEndtime - dtStarttime).Seconds;
            sbmessage.Append(Totaltime.ToString() + "Total seconds load time");

            Label1.Text = sbmessage.ToString();

        }

        private DataSet GetEmployeesData()
        {

            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Trusted_Connection=true;initial catalog=master;");
            SqlCommand cmd = new SqlCommand("SPEmployee");
            cmd.Connection = con;

            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet dsProducts = new DataSet();
            adp.Fill(dsProducts);
            return dsProducts;

        }
    }




}
