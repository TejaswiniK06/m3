using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace Applicationstatemanagement
{
    public partial class DataCaching : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Trusted_Connection=true;initial catalog=master;");
                SqlCommand cmd = new SqlCommand("SPEmployee");
                cmd.Connection = con;

                con.Open();
                cmd.CommandType =CommandType.StoredProcedure;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                con.Close();
               Cache["data"] = ds;     // Storing dataset in cache "data"
                GdViewSearch.DataSource = ds;
                GdViewSearch.DataBind();
                Label1.Text = "Server Time" + DateTime.Now;
         
            }
            //else{
            //    GdViewSearch.DataSource = (DataSet)Cache["data"];   // binding the GdViewSearch from dataset from cache and not calling BindGrid()
            //    GdViewSearch.DataBind();
            //    Label1.Text="The data is reterived from cache"+DateTime.Now;
            //}
        }



            










        }


    

