using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace AuthenticateLogic
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            string Connection = ConfigurationManager.ConnectionStrings["DBCS"].ToString();
            using (SqlConnection Con = new SqlConnection(Connection))
            {

                SqlCommand cmd = new SqlCommand("spRegisterUser", Con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter paramUsername = new SqlParameter("@UserName", txtUname.Text);
                SqlParameter paramPassword = new SqlParameter("@Password", txtpwd.Text);
                SqlParameter paramEmail = new SqlParameter("@Email", txtpwd.Text);
                cmd.Parameters.Add(paramUsername);
                cmd.Parameters.Add(paramPassword);
                cmd.Parameters.Add(paramEmail);

                Con.Open();
                int ReturnCode = cmd.ExecuteNonQuery();
                if (ReturnCode == 1)
                {
                    Response.Write("Successfuly Inserted");

                }
                Con.Close();

            }
        }
    }
}
