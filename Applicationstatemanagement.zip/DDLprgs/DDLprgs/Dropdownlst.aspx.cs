﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace DDLprgs
{
    public partial class Dropdownlst : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                //AppendDataBoundItems="true"

//The AppendDataBoundItems property allows you to add items to the ListControl object before data binding occurs. 
                //After data binding, the items collection contains both the items from the data source and the previously added items.
              

                ddlCountry.AppendDataBoundItems = true;
                string strConnString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=master;Trusted_Connection=true";

                String strQuery = "select FLDcountryID, FLDcountryname from TblCountry";
                SqlConnection con = new SqlConnection(strConnString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cmd.Connection = con;
                try
                {
                    con.Open();
                    ddlCountry.DataSource = cmd.ExecuteReader();
                    ddlCountry.DataTextField = "FLDcountryname";
                    ddlCountry.DataValueField = "FLDcountryID";
                    ddlCountry.DataBind();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

       

        protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
        {


            ddlCity.Items.Clear();
            ddlCity.Items.Add(new ListItem("--Select City--", ""));
            ddlCity.AppendDataBoundItems = true;
            string strConnString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=master;Trusted_Connection=true";
            string strQuery = "select FldCittyid, FldSCityName from TblCity " +
                                        "where FldStateid=@Stateid";
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Stateid",
                                  ddlstate.SelectedItem.Value);
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = strQuery;
            cmd.Connection = con;
            try
            {
                con.Open();
                ddlCity.DataSource = cmd.ExecuteReader();
                ddlCity.DataTextField = "FldSCityName";
                ddlCity.DataValueField = "FldCittyid";
                ddlCity.DataBind();
                if (ddlCity.Items.Count > 1)
                {
                    ddlCity.Enabled = true;
                }
                else
                {
                    ddlCity.Enabled = false;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }














        }

        protected void ddlCountry_SelectedIndexChanged1(object sender, EventArgs e)
        {
            ddlstate.Items.Clear();
            ddlstate.Items.Add(new ListItem("--Select State--", ""));
            ddlCity.Items.Clear();
            ddlCity.Items.Add(new ListItem("--Select City--", ""));

            ddlstate.AppendDataBoundItems = true;
            string strConnString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=master;Trusted_Connection=true";

            string  strQuery = "select FLDstateid, FldStateName from TblState " +
                               "where FLDcountryid=@FLDcountryid";
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@FLDcountryid",
                ddlCountry.SelectedItem.Value);
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = strQuery;
            cmd.Connection = con;
            try
            {
                con.Open();
                ddlstate.DataSource = cmd.ExecuteReader();
                ddlstate.DataTextField = "FLDStateName";
                ddlstate.DataValueField = "FLDStateid";
                ddlstate.DataBind();
                if (ddlstate.Items.Count > 1)
                {
                    ddlstate.Enabled = true;
                }
                else
                {
                    ddlstate.Enabled = false;
                    ddlCity.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
}