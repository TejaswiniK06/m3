﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Dopostback
{
    public partial class Cmdnameprg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }
        //        void
        protected void Button_Command(object sender, CommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "SubmitButtonCommand":
                    label1.Text = "Submit Button Clicked";
                    break;
                case "CancelButtonCommand":
                    label1.Text = "Cancel Button Clicked";
                    break;



            }




        }

    }
}
